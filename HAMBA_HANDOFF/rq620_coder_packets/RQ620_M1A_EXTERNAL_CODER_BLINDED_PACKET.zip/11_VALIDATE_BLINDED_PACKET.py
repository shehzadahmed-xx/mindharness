from __future__ import annotations

import csv
import json
import sys
from pathlib import Path


def rows(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    obligations = rows(root / "04_BLINDED_CELL_OBLIGATIONS.csv")
    decisions = rows(root / "06_CODER_DECISIONS_BLANK.csv")
    forbidden = {"original_gain", "gain", "ordinal_score", "weight", "allocated_gain", "persona", "m2"}
    headers = set(decisions[0]) if decisions else set()
    checks = {
        "obligations_33": len(obligations) == 33,
        "decisions_33": len(decisions) == 33,
        "cell_ids_match": {r["allocation_cell_id"] for r in obligations} == {r["allocation_cell_id"] for r in decisions},
        "forbidden_headers_absent": not (headers & forbidden),
        "original_values_absent": all("original_gain" not in r and "ordinal_score" not in r for r in obligations),
        "all_decisions_initially_blank": all(r["coder_decision"] == "" for r in decisions),
        "all_gate_states_unassessed": all(
            r[field] == "UNASSESSED"
            for r in decisions
            for field in ("complete_denominator", "temporal_alignment", "perimeter_alignment", "source_traceability")
        ),
    }
    result = {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "weights_computed": 0, "gains_computed": 0}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
