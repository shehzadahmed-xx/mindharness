# Adjudication rules

1. R1 is permitted only when the frozen construct is exclusively attributable to exactly one frozen component for the same event, window, and perimeter.
2. R2 is permitted only when both component numerators are observed in the same unit, window, perimeter, and complete denominator.
3. A role label, financing ceiling, announced transaction, aggregate liability, capacity figure, or legal authority is not automatically a numerator.
4. Missing, conflicting, incommensurable, temporally misaligned, or incomplete evidence resolves to R3 null.
5. Do not calculate a share, weight, or allocated gain. Return evidence and gate states only.
6. Coder disagreement remains R3 null until documented adjudication by an independent third party.
