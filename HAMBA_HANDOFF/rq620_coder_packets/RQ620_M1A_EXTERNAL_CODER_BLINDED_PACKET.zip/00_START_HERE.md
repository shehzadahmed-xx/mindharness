# RQ-620 external-coder blinded packet

This packet is for a genuinely external coder or replication team. It contains no original gain values, ordinal scores, allocation decisions, weights, personas, or engine outputs.

Your task is to retrieve and code component-level provenance for each of the 33 obligations. Record facts and gate states only. Do not calculate allocation weights or gains. Do not request or inspect the full M1A recovery package until your submission has been sealed and returned.

The submission must be attributable to real personnel. Preparation of this packet does not establish independence.
